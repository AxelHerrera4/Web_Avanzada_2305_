import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, ReactiveFormsModule, CommonModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'], 
})
export class AppComponent {
  title = 'pryformReactivo';

  
  formularioRegistro = new FormGroup({
    nombre: new FormControl('', Validators.required),
    email: new FormControl('', [
      Validators.required,
      Validators.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/),
    ]),
    contrasena: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.pattern(/^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>]).{6,}$/),
    ]),
  });

  submitted = false; 
  mensajeExito = '';

  submit() {
    this.submitted = true; 
  
    if (this.formularioRegistro.valid) {
      const nombre = this.formularioRegistro.get('nombre')?.value;
      const email = this.formularioRegistro.get('email')?.value;
  
      if (nombre && email) {
        this.mensajeExito = `Usted, ${nombre}, con el correo ${email}, ha registrado una cuenta exitosamente.`;
      } else {
        this.mensajeExito = 'No se han podido extraer los valores del formulario.';
      }
  
      this.formularioRegistro.reset(); // Reinicia el formulario
      this.submitted = false;         // Reinicia el estado de envío
    } else {
      this.mensajeExito = 'No se ha podido registrar la cuenta.';
    }
  }
}
